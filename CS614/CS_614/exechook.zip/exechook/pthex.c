#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<pthread.h>


int set_tracked_pid(int pid)
{
	char buf[16];
	int fd = open("/sys/kernel/cs614hook/tracked_pid", O_RDWR);
	if(fd < 0){
		perror("open");
		return fd;
	}
        sprintf(buf, "%d", pid);
	if(write(fd, buf, 16) < 0){
		perror("open");
		return -1;
	}
	printf("Process %d is being tracked now\n", pid);
	return 0;
}


int main()
{
   int pid;
   pthread_t tid;

   assert(set_tracked_pid(getpid()) == 0);
  
   printf("My pid %d\n", getpid());
   execl("/bin/ls", "ls", NULL);

  perror("exec");
  return 0;
}
