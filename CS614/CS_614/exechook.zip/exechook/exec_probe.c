#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/sched.h>
#include<linux/sched/task_stack.h>
#include <linux/kprobes.h>
#include<linux/binfmts.h>

static int tracked_pid;

static int __kprobes before(struct kprobe *p, struct pt_regs *regs)
{
  struct mm_struct *mm = current->mm; 
  struct vm_area_struct *vma;
  MA_STATE(mas, &mm->mm_mt, 0, 0);

  if(current->pid != tracked_pid) 
	  return 0;

  mas_for_each(&mas, vma, ULONG_MAX) {
	 printk(KERN_INFO "start: %lx end: %lx flags: %lx\n", vma->vm_start, vma->vm_end,  vma->vm_flags); 
  }                        

  return 0;	
}


static struct kprobe kp_clone = {
        .symbol_name   = "free_bprm",
//        .symbol_name   = "do_close_on_exec",
	.pre_handler = before,
	.post_handler = NULL,
};



static ssize_t read_pid(struct kobject *kobj,
                                  struct kobj_attribute *attr, char *buf)
{
        return sprintf(buf, "%d\n", tracked_pid);
}

static ssize_t set_pid(struct kobject *kobj,
                                   struct kobj_attribute *attr,
                                   const char *buf, size_t count)
{
        int newval;
        int err = kstrtoint(buf, 10, &newval);
        if (err || newval < 0)
                return -EINVAL;
	printk(KERN_INFO "Tracked process pid = %d\n",newval); 
        tracked_pid = newval;
        return count;
}

static struct kobj_attribute forkpidhook_attribute = __ATTR(tracked_pid, 0644, read_pid, set_pid);


static struct attribute *forkhook_attrs[] = {
        &forkpidhook_attribute.attr,
        NULL,
};
static struct attribute_group traphook_attr_group = {
        .attrs = forkhook_attrs,
        .name = "cs614hook",
};

int init_module(void)
{
	int ret;
	printk(KERN_INFO "Setting the probe\n");
	ret = register_kprobe(&kp_clone);
        if (ret < 0) {
                printk(KERN_INFO "register_kprobe failed, returned %d\n", ret);
                return ret;
        }
        printk(KERN_INFO "Planted kprobe at %lx\n", (unsigned long)kp_clone.addr);
	
	ret = sysfs_create_group (kernel_kobj, &traphook_attr_group);
        if(unlikely(ret))
                printk(KERN_INFO "demo: can't create sysfs\n");
        return 0;
}

void cleanup_module(void)
{
        sysfs_remove_group (kernel_kobj, &traphook_attr_group);
        unregister_kprobe(&kp_clone);
	printk(KERN_INFO "Removed the probes\n");
}
MODULE_LICENSE("GPL");
